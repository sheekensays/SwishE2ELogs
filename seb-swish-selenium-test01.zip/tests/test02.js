module.exports = {

    before : function (browser) {
        console.log("Starting up..");
        browser.url('https://internalapps-tst.sebank.se/shell/payments/swish/SwishAgreements?customer=5568495310')
    },

    after : function (browser) {
        console.log("Ending now..");
        browser.end()
    },

    'CreateDeleteAgreement_Corporate' : function (browser) {
        browser
        .waitForElementPresent('body', 10000)
        .waitForElementPresent('div.table-responsive', 60000)
        .waitForElementPresent('div.customerNumber')
        .assert.containsText('div.customerNumber', '5568495310')

        //Create
        .waitForElementPresent('#addNewButton')
        .click('#addNewButton')
        .waitForElementPresent('form.ng-untouched.ng-pristine.ng-invalid')
        
        //Radio Button
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(1)')
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(2)')

        //SwishName
        .waitForElementPresent('input.form-control.ng-valid')
        .setValue('input.form-control.ng-valid', 'TestSwishName')

        //CustomerNumber
        .waitForElementPresent('div.btn.btn-secondary.custom-dropdown-toggle')
        .click('div.btn.btn-secondary.custom-dropdown-toggle')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(1)')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .click('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .assert.containsText('div.btn.btn-secondary.custom-dropdown-toggle', '56971040198')

        //SwishNumber
        .waitForElementPresent('#radioGrpSwishNumberOption > div > div > div:nth-child(1)')
        .waitForElementPresent('#radioGrpSwishNumberOption > div > div > div:nth-child(2)')
        //BookNewSwishNumber
        .click('div.input-group-append')
        .pause(5*1000)

        //ClickCreate
        .waitForElementPresent('button.btn.btn-sm.btn-primary')
        .click('button.btn.btn-sm.btn-primary')
        .pause(5*1000)

        //DeleteNewAgreement
        //Search
        .waitForElementPresent('#search_input')
        .click('#search_input')
        .setValue('#search_input', 'TestSwishName')

        //MoreOptions
        .waitForElementPresent('button.btn.btn-link.btn-sm')
        .click('button.btn.btn-link.btn-sm')
        .waitForElementPresent('div.modal-body')

        //Click delete
        .waitForElementPresent('#remove-button')
        .click('#remove-button')

        .waitForElementPresent('div.dialogue.with-desc')
        .waitForElementPresent('button.btn.btn-primary.dialogue-button')
        .click('button.btn.btn-primary.dialogue-button')
        
        .pause(5*1000)
        
    },
    
    'CreateDeleteAgreement_Ecommerce' : function (browser) {
        browser
        .waitForElementPresent('body', 10000)
        .waitForElementPresent('div.table-responsive', 60000)
        .waitForElementPresent('div.customerNumber')
        .assert.containsText('div.customerNumber', '5568495310')

        //Create
        .waitForElementPresent('#addNewButton')
        .click('#addNewButton')
        .waitForElementPresent('form.ng-untouched.ng-pristine.ng-invalid')
        
        //AgreementType
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(1)')
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(2)')
        .pause(500)
        .click('#radioGrpAgreementType > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > input')

        //SwishName
        .waitForElementPresent('input.form-control.ng-valid')
        .setValue('input.form-control.ng-valid', 'TestAgreement')

        //CustomerNumber
        .waitForElementPresent('div.btn.btn-secondary.custom-dropdown-toggle')
        .click('div.btn.btn-secondary.custom-dropdown-toggle')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(1)')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .click('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .assert.containsText('div.btn.btn-secondary.custom-dropdown-toggle', '56971040198')

        //BookNewSwishNumber
        .click('div.input-group-append')
        .pause(5*1000)
        
        //ClickCreate
        .waitForElementPresent('button.btn.btn-sm.btn-primary')
        .click('button.btn.btn-sm.btn-primary')
        .pause(5*1000)

        //DeleteNewAgreement
        //Search
        .waitForElementPresent('#search_input')
        .click('#search_input')
        .setValue('#search_input', 'TestAgreement')

        //MoreOptions
        .waitForElementPresent('button.btn.btn-link.btn-sm')
        .click('button.btn.btn-link.btn-sm')
        .waitForElementPresent('div.modal-body')

        //Click delete
        .waitForElementPresent('#remove-button')
        .click('#remove-button')

        .waitForElementPresent('div.dialogue.with-desc')
        .waitForElementPresent('button.btn.btn-primary.dialogue-button')
        .click('button.btn.btn-primary.dialogue-button')
        .pause(5*1000)
        
        //Confirm delete
        //Search
        .waitForElementPresent('#search_input')
        .click('#search_input')
        .clearValue('#search_input')
        .setValue('#search_input', 'TestAgreement')

        .waitForElementPresent('label.label-noData', 10*1000)
        .assert.containsText('label.label-noData', 'Det gick inte att hitta några resultat som matchar ditt sökord.')

    }

}
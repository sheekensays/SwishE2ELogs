module.exports = {

    before : function (browser) {
        console.log("Starting up..");
        browser.url('https://www.google.com')
    },

    after : function (browser) {
        console.log("Ending now..");
        browser.end()
    },

    'TestCase_topdanmark' : function (browser) {
        browser
        //.fullscreenWindow()
        .waitForElementPresent('body', 1000)
        .setValue('input[type=text]', 'topdanmark')
        .keys(browser.Keys.ENTER)
        .pause(1000)
        .assert.containsText('#main', 'topdanmark')
    },

    'TestCase_New' : function (browser) {
        browser
        //Open Homepage
        .url('https://internalapps-tst.sebank.se/shell/payments/swish/SwishAgreements?customer=5568495310')
        .waitForElementPresent('body', 10000)
        .waitForElementPresent('div.table-responsive', 60000)
        .waitForElementPresent('div.customerNumber')
        .assert.containsText('div.customerNumber', '5568495310')

        //Create
        .waitForElementPresent('#addNewButton')
        .click('#addNewButton')
        .waitForElementPresent('form.ng-untouched.ng-pristine.ng-invalid')
        
        //Radio Button
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(1)')
        .waitForElementPresent('#radioGrpAgreementType > div > div > div:nth-child(2)')

        //SwishName
        .waitForElementPresent('input.form-control.ng-valid')
        .setValue('input.form-control.ng-valid', 'TestSwishName')

        //CustomerNumber
        .waitForElementPresent('div.btn.btn-secondary.custom-dropdown-toggle')
        .click('div.btn.btn-secondary.custom-dropdown-toggle')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(1)')
        .waitForElementPresent('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .click('button.dropdown-item.custom-dropdown-item:nth-child(3)')
        .assert.containsText('div.btn.btn-secondary.custom-dropdown-toggle', '56971040198')

        //SwishNumber
        .waitForElementPresent('#radioGrpSwishNumberOption > div > div > div:nth-child(1)')
        .waitForElementPresent('#radioGrpSwishNumberOption > div > div > div:nth-child(2)')
        //BookNewSwishNumber
        .click('div.input-group-append')

        //ClickCreate
        .waitForElementPresent('button.btn.btn-sm.btn-primary')
        .pause(5*1000)

        //.click('button.btn.btn-sm.btn-primary')
    },

    'TestCase_New02' : function (browser) {
        browser
        //Open Homepage
        .url('https://internalapps-tst.sebank.se/shell/payments/swish/SwishAgreements?customer=5568495310')
        .waitForElementPresent('body', 10000)
        .waitForElementPresent('div.table-responsive', 60000)
        .waitForElementPresent('div.customerNumber')
        .assert.containsText('div.customerNumber', '5568495310')

        //Search
        .waitForElementPresent('#search_input')
        .click('#search_input')
        .setValue('#search_input', '1230960922')

        .waitForElementPresent('app-table-layout > div.row > div > div > table > tbody > tr:nth-child(1)')
        .waitForElementNotPresent('app-table-layout > div.row > div > div > table > tbody > tr:nth-child(2)')

        //Remove Search
        .click('#search_input')
        .clearValue('#search_input')

        .pause(5*1000)
    },

    'TestCase_New03' : function (browser) {
        browser
        //Open Homepage
        .url('https://internalapps-tst.sebank.se/shell/payments/swish/SwishAgreements?customer=5568495310')
        .waitForElementPresent('body', 10000)
        .waitForElementPresent('div.table-responsive', 60000)
        .waitForElementPresent('div.customerNumber')
        .assert.containsText('div.customerNumber', '5568495310')

        //Search
        .waitForElementPresent('#historyButton')
        .click('#historyButton')

        .waitForElementPresent('div.table-responsive')
        .waitForElementPresent('table > tbody > tr:nth-child(1) > td:nth-child(1)')
        .click('table > tbody > tr:nth-child(1) > td:nth-child(1)')
        .waitForElementPresent('#divBody > div > app-table-layout > div > div > div')

        
        
        .pause(5*1000)
    }


}